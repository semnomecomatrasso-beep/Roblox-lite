const toast=document.getElementById('toast');
function info(name){toast.textContent=name+' é um espaço demonstrativo. Jogos próprios poderão ser adicionados aqui.';toast.classList.add('show');setTimeout(()=>toast.classList.remove('show'),2600)}
document.getElementById('perf').addEventListener('change',e=>{document.body.classList.toggle('reduce-motion',e.target.checked);info(e.target.checked?'Modo desempenho ativado':'Animações da interface ativadas')});
document.body.classList.add('reduce-motion');
// Estimativa de atualização da interface; não representa FPS de renderização 3D.
let last=performance.now(),frames=0;
function tick(now){frames++;if(now-last>=1000){document.getElementById('fps').textContent=Math.min(120,Math.round(frames*1000/(now-last)));frames=0;last=now}requestAnimationFrame(tick)}
requestAnimationFrame(tick);
