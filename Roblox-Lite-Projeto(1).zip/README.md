# ROBLOX LITE (projeto independente)

Launcher Android demonstrativo com interface escura/vermelha, biblioteca de cartões de jogos fictícios e modo de redução de animações.

## Importante
- Este projeto **não é o Roblox oficial** e não acessa nem executa experiências da plataforma Roblox.
- Os cartões são demonstrativos. Para jogar, será necessário desenvolver/integrar jogos próprios.
- O número exibido no painel é uma estimativa de atualização da interface, **não é uma medição de FPS de jogos 3D**.
- Nenhum aplicativo consegue garantir 120 FPS em todo aparelho ou jogo; isso depende do hardware, do motor gráfico e do conteúdo.

## Compilar no GitHub
1. Crie um repositório e envie todos os arquivos desta pasta.
2. Abra a aba **Actions** e habilite GitHub Actions, se solicitado.
3. Um push na branch `main`/`master` compila e salva o APK em **Artifacts**.
4. Para criar uma Release: crie e envie uma tag, por exemplo:
   ```bash
   git tag v1.0.0
   git push origin v1.0.0
   ```
5. O workflow compila o APK e anexa `Roblox-Lite-1.0.apk` à Release automaticamente.

## Compilar localmente
Requer JDK 17 e Android SDK 35:
```bash
gradle assembleDebug
```
APK em `app/build/outputs/apk/debug/app-debug.apk`.
